/**
*
*
*
**/
module.exports.PORT = 3001;
/**
*
*
*
**/
module.exports.DB = {
    host:'localhost',
    user:'root',
    password:'',
    database:'test'
}
/**
*
*
*
**/