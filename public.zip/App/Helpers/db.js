const mysql = require('mysql');
const { DB } = require('../../config');

const db = mysql.createConnection(DB);

db.connect((error) =>{
    if(!error){
        // console.log('DB Connected.............');
    }else{
        console.log('DB Connection Failed.............');
    }
});

module.exports = db;