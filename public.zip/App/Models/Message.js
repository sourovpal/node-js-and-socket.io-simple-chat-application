const db = require("../Helpers/db");
const moment = require('moment');


module.exports.getMessage = async(sender_id, receiver_id)=>{
    return await new Promise((resolve, reject)=>{
        db.query(`SELECT * FROM tbl_chats WHERE 
        (sender_id =${sender_id} AND receiver_id=${receiver_id}) OR 
        (sender_id =${receiver_id} AND receiver_id=${sender_id}) ORDER BY created_at ASC`, (error, messages)=>{
            if(!error){
                return resolve(messages);
            }
            return reject(error);
        });
    });
};

module.exports.saveMessage = async({sender_id, receiver_id, message})=>{
    return await new Promise((resolve, reject)=>{
        const currentTime = moment(Date.now()).format();
        const formData = {
            sender_id,
            receiver_id,
            message,
            created_at:currentTime,
            updated_at:currentTime,
        }
        db.query(`INSERT INTO tbl_chats SET ?`, formData, (error, result)=>{
            if(!error){
                return resolve(formData);
            }
            return reject(error);
        });
    });
}