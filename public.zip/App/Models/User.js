const db = require('../Helpers/db');
const moment = require('moment');

module.exports.status = async(id, status)=>{
    return new Promise((resolve, reject)=>{
        const currentTime = moment(Date.now()).format();
        db.query('UPDATE tbl_users SET status=?, updated_at=? WHERE id=?', [status, currentTime, id], (error, result)=>{
            if(!error){
                return resolve(result);
            }
            return reject(error);
        });
    });
}
module.exports.get = async()=>{
    return new Promise((resolve, reject)=>{
        db.query('SELECT * FROM tbl_users WHERE deleted_at IS NULL ORDER BY status DESC', (error, result)=>{
            if(!error){
                return resolve(result);
            }
            return reject(error);
        });
    });
}