const express = require('express');
const route = express.Router();
const AuthMiddleware = require('../App/Middlewares/AuthMiddleware');

route.use(AuthMiddleware);

route.get('/', (req, res)=>{
    res.render('pages/home', {
        title:'Chat Application',
        user:req.session.user
    });
});
/**
*
*
*
**/
module.exports = route;